import os
import json
import boto3
import logging
from botocore.exceptions import ClientError

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['TABLE_NAME'])

def lambda_handler(event, context):
    """
    Handles WebSocket $connect events and stores connection IDs in DynamoDB.
    Includes detailed logging for testing purposes.
    """
    connection_id = event['requestContext']['connectionId']
    timestamp = event['requestContext'].get('connectedAt', '')
    
    logger.info(f"New connection attempt - Connection ID: {connection_id}")
    logger.info(f"Full event: {json.dumps(event)}")
    
    try:
        # Store the connection ID in DynamoDB
        table.put_item(
            Item={
                'connectionId': connection_id,
                'timestamp': timestamp,
                'connectionInfo': {
                    'sourceIP': event['requestContext'].get('identity', {}).get('sourceIp', 'unknown'),
                    'userAgent': event['requestContext'].get('identity', {}).get('userAgent', 'unknown')
                }
            }
        )
        
        logger.info(f"Successfully stored connection ID: {connection_id}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Connected successfully',
                'connectionId': connection_id
            })
        }
        
    except ClientError as e:
        logger.error(f"Error storing connection ID: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Failed to connect',
                'error': str(e)
            })
        }